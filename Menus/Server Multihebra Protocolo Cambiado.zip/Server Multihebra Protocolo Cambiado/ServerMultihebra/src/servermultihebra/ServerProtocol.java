
package servermultihebra;


/**
 *
 * @author Javerro
 */
public class ServerProtocol {
     private static final int WAITING = 0;
    private static final int SENTKNOCKKNOCK = 1;
    private static final int SENTCLUE = 2;
    private static final int ANOTHER = 3;

    private static final int NUMJOKES = 5;

    private int state = WAITING;
    private int currentJoke = 0;

    private String[] clues = { "Turnip", "Little Old Lady", "Atch", "Who", "Who" };
    private String[] answers = { "Turnip the heat, it's cold in here!",
                                 "I didn't know you could yodel!",
                                 "Bless you!",
                                 "Is there an owl in here?",
                                 "Is there an echo in here?" };
public String processInput(String theInput) {
        String theOutput = null;

        if (state == WAITING) {
            theOutput = "Introduzca su nombre";
            state = SENTKNOCKKNOCK;
        } 
        else if (state == SENTKNOCKKNOCK) {
            if (theInput.equalsIgnoreCase("Alex")) {
                theOutput = "Tu apellido es: Pedrosa";
                state = SENTCLUE;
            }
                else if(theInput.equalsIgnoreCase("Antonio")){
                     theOutput = "Tu apellido es: Carrasco";
                }
                    else if (theInput.equalsIgnoreCase("Ramon")) {
                         theOutput = "Tu apellido es: Pozo";
                    }
                    else if(theInput.equalsIgnoreCase("Gonzalo")){
                        theOutput = "Tu apellido es: Jurado";
                    }
                        else if(theInput.equalsIgnoreCase("Jesus")){
                            theOutput = "Tu apellido es: Maestro";
                    }
                            else if(theInput.equalsIgnoreCase("Jesus Alejandro")){
                                theOutput = "Tu apellido es: Cordoba";
                            }
        }
        
        return theOutput;
    }
}
